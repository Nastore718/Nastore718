const chalk = require("chalk")
const fs = require("fs")

const payment = {
    qris: {
      atas_nama: "WINK STORE"
    },
    dana: {
      nomer: "083170391302",
      atas_nama: "KRXXXA"
    },
    ovo: {
      nomer: "083170391300", //
      atas_nama: "NA STORE" 
    }
}

//DATA AKUN ORKUT AGAR FITUR BISA DIGUNAKAN 
//WAJIB DI ISI
const idOrkut = "OK2100276" //ganti dengan id orkut kamu
const pwOrkut = "krisna123456789" //ganti dengan pw orkut kamu
const pinOrkut = "2011" //ganti dengan pin orkut kamu

  global.ownerNumber = "6283185532368@s.whatsapp.net"
  global.kontakOwner = "6283185532368"
  global.untung = "4"
  //Ini profit yg kamu dapat, 4 = 4% maka harga akan meningkat 4%
  //Isi sesuai kebutuhan 
  global.namaStore = "NA STORE"
  global.botName = "KONVEE"
  global.ownerName = "NA STORE"
  
  
  global.linkyt = "link chanel yt lu"
  global.linkig = "link akun ig lu"
  global.dana = "083170391301"
  global.sawer = "Scan qris di atas"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})

module.exports = { payment, idOrkut, pwOrkut, pinOrkut }